clear all;close all;clc;

imgDir = '../dataset';
outDir1= './result';
outDir2= './mat';
mkdir(outDir1);
mkdir(outDir2);
D= dir(fullfile(imgDir,'*.jpg'));

for i =1:numel(D),
    outFile1 = fullfile(outDir1,[D(i).name(1:end-4) '.jpg']);
    outFile2 = fullfile(outDir2,[D(i).name(1:end-4) '.mat']);
    if exist(outFile1,'file'), continue; end
    if exist(outFile2,'file'), continue; end
    imgFile=fullfile(imgDir,D(i).name);
    I=imread(imgFile);
    %your code here
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    a=rgb2gray(I);  
    level = graythresh(a);  
    a=im2bw(a,level);
    imwrite(a,outFile1);
    imgLabel=bwlabel(a);
    save(outFile2,'imgLabel');
    

end
