clear all;close all;clc;

imgDir = '/Users/tangning/Documents/MATLAB/BSR2/BSDS500/data/images/test';
outDir1= '/Users/tangning/Documents/MATLAB/canny/result';
outDir2= '/Users/tangning/Documents/MATLAB/canny/mat';
mkdir(outDir1);
mkdir(outDir2);
D= dir(fullfile(imgDir,'*.jpg'));

for i =1:numel(D),
    outFile1 = fullfile(outDir1,[D(i).name(1:end-4) '.jpg']);
    outFile2 = fullfile(outDir2,[D(i).name(1:end-4) '.mat']);
    if exist(outFile1,'file'), continue; end
    if exist(outFile2,'file'), continue; end
    imgFile=fullfile(imgDir,D(i).name);
    I=imread(imgFile);
    %your code here
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    I=rgb2gray(I);
    BW=edge(I,'canny');
    %BW=edge(I,'roberts');
    %BW=edge(I,'prewitt');
    %BW=edge(I,'log');
    %BW=edge(I,'sobel');
    BW=imfill(BW,'holes');
    imgLabel=bwlabel(BW);
    imwrite(BW,outFile1);
    save(outFile2,'imgLabel');

end
