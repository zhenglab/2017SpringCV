/*
 * Throwable.
 */
#include "lang/exceptions/throwable.hh"

namespace lang {
namespace exceptions {

/*
 * Pure virtual destructor.
 */
throwable::~throwable() { }

} /* namespace exceptions */
} /* namespace lang */
