/*
 * Input stream for deserialization.
 */
#include "io/serialization/serial_input_stream.hh"

namespace io {
namespace serialization {

/*
 * Pure virtual destructor.
 */
serial_input_stream::~serial_input_stream() { }

} /* namespace serialization */
} /* namespace io */
