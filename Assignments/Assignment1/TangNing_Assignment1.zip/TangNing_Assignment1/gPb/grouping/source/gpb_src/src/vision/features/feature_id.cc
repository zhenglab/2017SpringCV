/*
 * Feature identity.
 */
#include "vision/features/feature_id.hh"

namespace vision {
namespace features {

/* 
 * Pure virtual destructor.
 */
feature_id::~feature_id() { }

} /* namespace features */
} /* namespace vision */
