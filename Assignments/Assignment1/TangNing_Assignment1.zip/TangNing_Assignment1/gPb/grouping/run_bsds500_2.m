addpath lib;

clear all;close all;clc;

imgDir = '../mat';
outDir = '../result/boundary';
mkdir(outDir);
D= dir(fullfile(imgDir,'*.jpg'));

tic;
for i =1:numel(D),
    outFile = fullfile(outDir,[D(i).name(1:end-4) '.png']);
    if exist(outFile,'file'), continue; end
    imgFile=fullfile(imgDir,D(i).name);
    gPb_orient = globalPb(imgFile);
    ucm = contours2ucm(gPb_orient, 'imageSize');
    imwrite(ucm,outFile);
end
toc;
