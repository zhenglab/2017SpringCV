Description:
This fold contains a program for mean shift.

IDE:
MATLAB 2013

Installation:
Change your input and output path. Then run demo.m.