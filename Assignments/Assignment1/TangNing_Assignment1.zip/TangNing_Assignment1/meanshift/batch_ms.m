clear all;
clc;

imgBSDPath = '../dataset/';
outputResLabPath = 'result/Label/';
outputResMSPath = 'result/MS/';
mkdir(outputResLabPath);
mkdir(outputResMSPath);

inputPath = dir(imgBSDPath);


th = 0.65;%Iteration accuracy
iteration = 5;%The number of iterations
hr = 20;%Color radius
hs = 30; %Spatial radius

    for imgNum = 1:length(inputPath)
        if inputPath(imgNum).name(1)=='.'
            continue;
        end
        inputImgName = strcat(inputPath(imgNum).name);
        inputImgName = strcat(imgBSDPath,inputImgName);
        inputImg = imread(inputImgName);
        [outputImg,aveMeanshift] = meanShiftPixCluster(inputImg,hs,hr,th,iteration);
        imgInf = processSuperpixelImage(outputImg);
        imgLabel = double(imgInf.segimage);
        % imshow(uint8(outputImg));

        outputResLabParaImg = [outputResLabPath inputPath(imgNum).name(1:end-4) '.mat'];
        outputResMSParaImg = [outputResMSPath inputPath(imgNum).name(1:end-4) '.png'];
        imwrite(uint8(outputImg),outputResMSParaImg);
        save(outputResLabParaImg,'imgLabel');
    end

