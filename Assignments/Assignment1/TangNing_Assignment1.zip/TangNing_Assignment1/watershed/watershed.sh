#!/bin/bash

INPUTDIR="../dataset"
OUTPUTDIR="./result"
PYFILE="./watershed.py"

INPUTLIST=$(ls $INPUTDIR)

for INPUTIMAGE in $INPUTLIST
do
python $PYFILE $INPUTDIR/$INPUTIMAGE $OUTPUTDIR/$INPUTIMAGE
done
