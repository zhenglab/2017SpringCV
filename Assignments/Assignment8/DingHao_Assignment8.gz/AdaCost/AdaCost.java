package weka.classifiers.meta;

import weka.classifiers.rules.JRip;
import java.io.*;
import java.util.*;
import weka.classifiers.*;
import weka.core.*;


public class AdaCost extends  RandomizableIteratedSingleClassifierEnhancer
    implements OptionHandler, Drawable,WeightedInstancesHandler, Sourcable, TechnicalInformationHandler
 
{
	    
    protected String defaultClassifierString()
    {
        return "weka.classifiers.rules.JRip";
    }

    public AdaCost()
    {
        m_MatrixSource = 1;
        m_OnDemandDirectory = new File(System.getProperty("user.dir"));
        m_CostMatrix = new CostMatrix(1);
        m_Classifier = new JRip();
        m_WeightThreshold = 100;
    }
    
    public String globalInfo()
    {
        return (new StringBuilder()).append("Class for cost-sensitive boosting a nominal class classifier ").append(getTechnicalInformation().toString()).toString();
    }

    public TechnicalInformation getTechnicalInformation()
    {
        TechnicalInformation technicalinformation = new TechnicalInformation(weka.core.TechnicalInformation.Type.INPROCEEDINGS);
        technicalinformation.setValue(weka.core.TechnicalInformation.Field.AUTHOR, "Wei Fan, Salvatore J.Stolfo");
        technicalinformation.setValue(weka.core.TechnicalInformation.Field.TITLE, "Experiments with a cost-sensitive boosting algorithm");
        technicalinformation.setValue(weka.core.TechnicalInformation.Field.BOOKTITLE, "Sixteenth International Conference on Machine Learning");
        technicalinformation.setValue(weka.core.TechnicalInformation.Field.YEAR, "1999");
        technicalinformation.setValue(weka.core.TechnicalInformation.Field.PAGES, "97-105");
        return technicalinformation;
    }

    
     public Enumeration listOptions()
    {
        Vector vector = new Vector(5);
        vector.addElement(new Option("\tMinimize expected misclassification cost. Default is to\n\treweight training instances according to costs per class", "M", 0, "-M"));
        vector.addElement(new Option("\tFile name of a cost matrix to use. If this is not supplied,\n\ta cost matrix will be loaded on demand. The name of the\n\ton-demand file is the relation name of the training data\n\tplus \".cost\", and the path to the on-demand file is\n\tspecified with the -N option.", "C", 1, "-C <cost file name>"));
        vector.addElement(new Option("\tName of a directory to search for cost files when loading\n\tcosts on demand (default current directory).", "N", 1, "-N <directory>"));
        vector.addElement(new Option("\tThe cost matrix in Matlab single line format.", "cost-matrix", 1, "-cost-matrix <matrix>"));
        vector.addElement(new Option("\tPercentage of weight mass to base training on.\n\t(default 100, reduce to around 90 speed up)", "P", 1, "-P <num>"));
        vector.addElement(new Option("\tUse resampling for boosting.", "Q", 0, "-Q"));
              
        for(Enumeration enumeration = super.listOptions(); enumeration.hasMoreElements(); vector.addElement(enumeration.nextElement()));
        return vector.elements();

    }
    
    
    public void setOptions(String as[])
        throws Exception
    {
        
        String s = Utils.getOption('P', as);
        if(s.length() != 0)
            setWeightThreshold(Integer.parseInt(s));
        else
            setWeightThreshold(100);
            
           
        setMinimizeExpectedCost(Utils.getFlag('M', as));
        String s1 = Utils.getOption('C', as);
        if(s1.length() != 0)
        {
            try
            {
                setCostMatrix(new CostMatrix(new BufferedReader(new FileReader(s1))));
            }
            catch(Exception exception)
            {
                setCostMatrix(null);
            }
            setCostMatrixSource(new SelectedTag(2, TAGS_MATRIX_SOURCE));
            m_CostFile = s1;
        } else
        {
            setCostMatrixSource(new SelectedTag(1, TAGS_MATRIX_SOURCE));
        }
        String s2 = Utils.getOption('D', as);
        if(s2.length() != 0)
            setOnDemandDirectory(new File(s2));
        String s3 = Utils.getOption("cost-matrix", as);
        if(s3.length() != 0)
        {
            StringWriter stringwriter = new StringWriter();
            CostMatrix.parseMatlab(s3).write(stringwriter);
            setCostMatrix(new CostMatrix(new StringReader(stringwriter.toString())));
            setCostMatrixSource(new SelectedTag(2, TAGS_MATRIX_SOURCE));
        }
        
            
        setUseResampling(Utils.getFlag('Q', as));
        if(m_UseResampling && s.length() != 0)
        {
            throw new Exception("Weight pruning with resamplingnot allowed.");
        } else
        {
            super.setOptions(as);
            return;
        }
        
    }
    
    
    public String[] getOptions()
    {
    	  String as[] = super.getOptions();
        String as1[] = new String[as.length + 9];
        int i = 0;
        if(m_MatrixSource == 2)
        {
            if(m_CostFile != null)
            {
                as1[i++] = "-C";
                as1[i++] = (new StringBuilder()).append("").append(m_CostFile).toString();
            } else
            {
                as1[i++] = "-cost-matrix";
                as1[i++] = getCostMatrix().toMatlab();
            }
        } else
        {
            as1[i++] = "-N";
            as1[i++] = (new StringBuilder()).append("").append(getOnDemandDirectory()).toString();
        }
        if(getMinimizeExpectedCost())
            as1[i++] = "-M";
       
    
        if(getUseResampling())
        {
            as1[i++] = "-Q";
            as1[i++] = "";
        } else
        {
            as1[i++] = "-P";
            as1[i++] = (new StringBuilder()).append("").append(getWeightThreshold()).toString();
        }
        System.arraycopy(as, 0, as1, i, as.length);        
          
            for(; i < as1.length; i++)
            if(as1[i] == null)
                as1[i] = "";
                
        return as1;
    }
    
    
    
    protected Instances selectWeightQuantile(Instances instances, double d)
    {
        int i = instances.numInstances();
        Instances instances1 = new Instances(instances, i);
        double ad[] = new double[i];
        double d1 = 0.0D;
        for(int j = 0; j < i; j++)
        {
            ad[j] = instances.instance(j).weight();
            d1 += ad[j];
        }

        double d2 = d1 * d;
        int ai[] = Utils.sort(ad);
        d1 = 0.0D;
        int k = i - 1;
        do
        {
            if(k < 0)
                break;
            Instance instance = (Instance)instances.instance(ai[k]).copy();
            instances1.add(instance);
            d1 += ad[ai[k]];
            if(d1 > d2 && k > 0 && ad[ai[k]] != ad[ai[k - 1]])
                break;
            k--;
        } while(true);
        if(m_Debug)
            System.err.println((new StringBuilder()).append("Selected ").append(instances1.numInstances()).append(" out of ").append(i).toString());
        return instances1;
    }
    
    
    
    public String weightThresholdTipText()
    {
        return "Weight threshold for weight pruning.";
    }

    public void setWeightThreshold(int i)
    {
        m_WeightThreshold = i;
    }

    public int getWeightThreshold()
    {
        return m_WeightThreshold;
    }

    public String useResamplingTipText()
    {
        return "Whether resampling is used instead of reweighting.";
    }

    public void setUseResampling(boolean flag)
    {
        m_UseResampling = flag;
    }

    public boolean getUseResampling()
    {
        return m_UseResampling;
    }


    public String costMatrixSourceTipText()
    {
        return (new StringBuilder()).append("Sets where to get the cost matrix. The two options areto use the supplied explicit cost matrix (the setting of the costMatrix property), or to load a cost matrix from a file when required (this file will be loaded from the directory set by the onDemandDirectory property and will be named relation_name").append(CostMatrix.FILE_EXTENSION).append(").").toString();
    }

    public SelectedTag getCostMatrixSource()
    {
        return new SelectedTag(m_MatrixSource, TAGS_MATRIX_SOURCE);
    }

    public void setCostMatrixSource(SelectedTag selectedtag)
    {
        if(selectedtag.getTags() == TAGS_MATRIX_SOURCE)
            m_MatrixSource = selectedtag.getSelectedTag().getID();
    }

    public String onDemandDirectoryTipText()
    {
        return "Sets the directory where cost files are loaded from. This option is used when the costMatrixSource is set to \"On Demand\".";
    }

    public File getOnDemandDirectory()
    {
        return m_OnDemandDirectory;
    }

    public void setOnDemandDirectory(File file)
    {
        if(file.isDirectory())
            m_OnDemandDirectory = file;
        else
            m_OnDemandDirectory = new File(file.getParent());
        m_MatrixSource = 1;
    }

    public String minimizeExpectedCostTipText()
    {
        return "Sets whether the minimum expected cost criteria will be used. If this is false, the training data will be reweighted according to the costs assigned to each class. If true, the minimum expected cost criteria will be used.";
    }

    public boolean getMinimizeExpectedCost()
    {
        return m_MinimizeExpectedCost;
    }

    public void setMinimizeExpectedCost(boolean flag)
    {
        m_MinimizeExpectedCost = flag;
    }

    protected String getClassifierSpec()
    {
        Classifier classifier = getClassifier();
        if(classifier instanceof OptionHandler)
            return (new StringBuilder()).append(classifier.getClass().getName()).append(" ").append(Utils.joinOptions(classifier.getOptions())).toString();
        else
            return classifier.getClass().getName();
    }

    public String costMatrixTipText()
    {
        return "Sets the cost matrix explicitly. This matrix is used if the costMatrixSource property is set to \"Supplied\".";
    }

    public CostMatrix getCostMatrix()
    {
        return m_CostMatrix;
    }

    public void setCostMatrix(CostMatrix costmatrix)
    {
        m_CostMatrix = costmatrix;
        m_MatrixSource = 2;
    }

    public Capabilities getCapabilities()
    {
        Capabilities capabilities = super.getCapabilities();
        capabilities.disableAllClasses();
        capabilities.disableAllClassDependencies();
        if(super.getCapabilities().handles(weka.core.Capabilities.Capability.NOMINAL_CLASS))
            capabilities.enable(weka.core.Capabilities.Capability.NOMINAL_CLASS);
        if(super.getCapabilities().handles(weka.core.Capabilities.Capability.BINARY_CLASS))
            capabilities.enable(weka.core.Capabilities.Capability.BINARY_CLASS);
        return capabilities;
    }
    
     public void buildClassifier(Instances instances)
        throws Exception
    {
        getCapabilities().testWithFail(instances);
        instances = new Instances(instances);
        instances.deleteWithMissingClass();
        if(m_Classifier == null)
            throw new Exception("No base classifier has been set!");
        if(m_MatrixSource == 1)
        {
            String s = (new StringBuilder()).append(instances.relationName()).append(CostMatrix.FILE_EXTENSION).toString();
            File file = new File(getOnDemandDirectory(), s);
            if(!file.exists())
                throw new Exception((new StringBuilder()).append("On-demand cost file doesn't exist: ").append(file).toString());
            setCostMatrix(new CostMatrix(new BufferedReader(new FileReader(file))));
        } else
        if(m_CostMatrix == null)
        {
            m_CostMatrix = new CostMatrix(instances.numClasses());
            m_CostMatrix.readOldFormat(new BufferedReader(new FileReader(m_CostFile)));
        }
        if(!m_MinimizeExpectedCost)
        {
            Random random = null;
            if(!(m_Classifier instanceof WeightedInstancesHandler))
                random = new Random(m_Seed);
            instances = m_CostMatrix.applyCostMatrix(instances, random);
        }
        
        startbuildClassifier(instances);
           
    }
    
    public void startbuildClassifier(Instances instances)
        throws Exception
    {
    	  super.buildClassifier(instances);
        getCapabilities().testWithFail(instances);
        instances = new Instances(instances);
        instances.deleteWithMissingClass();
        m_NumClasses = instances.numClasses();
        if(!m_UseResampling && (m_Classifier instanceof WeightedInstancesHandler))
            buildClassifierWithWeights(instances);
        else
            buildClassifierUsingResampling(instances);

    }

    protected void buildClassifierUsingResampling(Instances instances)
        throws Exception
    {
        int i = instances.numInstances();
        Random random = new Random(m_Seed);
        boolean flag = false;
        m_Betas = new double[m_Classifiers.length];
        m_NumIterationsPerformed = 0;
        Instances instances3 = new Instances(instances, 0, i);
        double d2 = instances3.sumOfWeights();
        for(int k = 0; k < instances3.numInstances(); k++)
            instances3.instance(k).setWeight(instances3.instance(k).weight() / d2);

        for(m_NumIterationsPerformed = 0; m_NumIterationsPerformed < m_Classifiers.length; m_NumIterationsPerformed++)
        {
            if(m_Debug)
                System.err.println((new StringBuilder()).append("Training classifier ").append(m_NumIterationsPerformed + 1).toString());
            Instances instances1;
            if(m_WeightThreshold < 100)
                instances1 = selectWeightQuantile(instances3, (double)m_WeightThreshold / 100D);
            else
                instances1 = new Instances(instances3);
            int j = 0;
            double ad[] = new double[instances1.numInstances()];
            for(int l = 0; l < ad.length; l++)
                ad[l] = instances1.instance(l).weight();

            double d;
            do
            {
                Instances instances2 = instances1.resampleWithWeights(random, ad);
                m_Classifiers[m_NumIterationsPerformed].buildClassifier(instances2);
                Evaluation evaluation = new Evaluation(instances);
                evaluation.evaluateModel(m_Classifiers[m_NumIterationsPerformed], instances3);
                d = evaluation.errorRate();
                j++;
            } while(Utils.eq(d, 0.0D) && j < MAX_NUM_RESAMPLING_ITERATIONS);
            if(Utils.grOrEq(d, 0.5D) || Utils.eq(d, 0.0D))
            {
                if(m_NumIterationsPerformed == 0)
                    m_NumIterationsPerformed = 1;
                break;
            }
            m_Betas[m_NumIterationsPerformed] = Math.log((1.0D - d) / d);
            double d1 = (1.0D - d) / d;
            if(m_Debug)
                System.err.println((new StringBuilder()).append("\terror rate = ").append(d).append("  beta = ").append(m_Betas[m_NumIterationsPerformed]).toString());
            setWeights(instances3, d1);
        }

    }
    
    
     protected void setWeights(Instances instances, double d)
        throws Exception
    {
        double d1 = instances.sumOfWeights();
        Enumeration enumeration = instances.enumerateInstances();
        do
        {
            if(!enumeration.hasMoreElements())
                break;
            Instance instance = (Instance)enumeration.nextElement();
            if(!Utils.eq(m_Classifiers[m_NumIterationsPerformed].classifyInstance(instance), instance.classValue()))
                instance.setWeight(instance.weight() * d);
        } while(true);
        double d2 = instances.sumOfWeights();
        Instance instance1;
        for(Enumeration enumeration1 = instances.enumerateInstances(); enumeration1.hasMoreElements(); instance1.setWeight((instance1.weight() * d1) / d2))
            instance1 = (Instance)enumeration1.nextElement();

    }

    protected void buildClassifierWithWeights(Instances instances)
        throws Exception
    {
        int i = instances.numInstances();
        Random random = new Random(m_Seed);
        m_Betas = new double[m_Classifiers.length];
        m_NumIterationsPerformed = 0;
        Instances instances2 = new Instances(instances, 0, i);
        for(m_NumIterationsPerformed = 0; m_NumIterationsPerformed < m_Classifiers.length; m_NumIterationsPerformed++)
        {
            if(m_Debug)
                System.err.println((new StringBuilder()).append("Training classifier ").append(m_NumIterationsPerformed + 1).toString());
            Instances instances1;
            if(m_WeightThreshold < 100)
                instances1 = selectWeightQuantile(instances2, (double)m_WeightThreshold / 100D);
            else
                instances1 = new Instances(instances2, 0, i);
            if(m_Classifiers[m_NumIterationsPerformed] instanceof Randomizable)
                ((Randomizable)m_Classifiers[m_NumIterationsPerformed]).setSeed(random.nextInt());
            m_Classifiers[m_NumIterationsPerformed].buildClassifier(instances1);
            Evaluation evaluation = new Evaluation(instances);
            evaluation.evaluateModel(m_Classifiers[m_NumIterationsPerformed], instances2);
            double d = evaluation.errorRate();
            if(Utils.grOrEq(d, 0.5D) || Utils.eq(d, 0.0D))
            {
                if(m_NumIterationsPerformed == 0)
                    m_NumIterationsPerformed = 1;
                break;
            }
            m_Betas[m_NumIterationsPerformed] = Math.log((1.0D - d) / d);
            double d1 = (1.0D - d) / d;
            if(m_Debug)
                System.err.println((new StringBuilder()).append("\terror rate = ").append(d).append("  beta = ").append(m_Betas[m_NumIterationsPerformed]).toString());
            setWeights(instances2, d1);
        }

    }


public double[] distributionForInstance(Instance instance)
        throws Exception
    {
        if(!m_MinimizeExpectedCost)
            return AgaindistributionForInstance(instance);
        double ad[] = m_Classifier.distributionForInstance(instance);
        double ad1[] = m_CostMatrix.expectedCosts(ad);
        int i = Utils.minIndex(ad1);
        for(int j = 0; j < ad.length; j++)
            if(j == i)
                ad[j] = 1.0D;
            else
                ad[j] = 0.0D;

        return ad;
      }
        
  public double[] AgaindistributionForInstance(Instance instance)
        throws Exception
       {    
         if(m_NumIterationsPerformed == 0)
            throw new Exception("No model built");
         double ad[] = new double[instance.numClasses()];
         if(m_NumIterationsPerformed == 1)
            return m_Classifiers[0].distributionForInstance(instance);
         for(int i = 0; i < m_NumIterationsPerformed; i++)
            ad[(int)m_Classifiers[i].classifyInstance(instance)] += m_Betas[i];

        return Utils.logs2probs(ad);
      }
      
      public int graphType()
    {
        if(m_Classifier instanceof Drawable)
            return ((Drawable)m_Classifier).graphType();
        else
            return 0;
    }

    public String graph()
        throws Exception
    {
        if(m_Classifier instanceof Drawable)
            return ((Drawable)m_Classifier).graph();
        else
            throw new Exception((new StringBuilder()).append("Classifier: ").append(getClassifierSpec()).append(" cannot be graphed").toString());
    }

 public String toSource(String s)
        throws Exception
    {
        if(m_NumIterationsPerformed == 0)
            throw new Exception("No model built yet");
        if(!(m_Classifiers[0] instanceof Sourcable))
            throw new Exception((new StringBuilder()).append("Base learner ").append(m_Classifier.getClass().getName()).append(" is not Sourcable").toString());
        StringBuffer stringbuffer = new StringBuffer("class ");
        stringbuffer.append(s).append(" {\n\n");
        stringbuffer.append("  public static double classify(Object [] i) {\n");
        if(m_NumIterationsPerformed == 1)
        {
            stringbuffer.append((new StringBuilder()).append("    return ").append(s).append("_0.classify(i);\n").toString());
        } else
        {
            stringbuffer.append((new StringBuilder()).append("    double [] sums = new double [").append(m_NumClasses).append("];\n").toString());
            for(int i = 0; i < m_NumIterationsPerformed; i++)
                stringbuffer.append((new StringBuilder()).append("    sums[(int) ").append(s).append('_').append(i).append(".classify(i)] += ").append(m_Betas[i]).append(";\n").toString());

            stringbuffer.append((new StringBuilder()).append("    double maxV = sums[0];\n    int maxI = 0;\n    for (int j = 1; j < ").append(m_NumClasses).append("; j++) {\n").append("      if (sums[j] > maxV) { maxV = sums[j]; maxI = j; }\n").append("    }\n    return (double) maxI;\n").toString());
        }
        stringbuffer.append("  }\n}\n");
        for(int j = 0; j < m_Classifiers.length; j++)
            stringbuffer.append(((Sourcable)m_Classifiers[j]).toSource((new StringBuilder()).append(s).append('_').append(j).toString()));

        return stringbuffer.toString();
    }
    
    
    public String toString()
    {
        StringBuffer stringbuffer = new StringBuffer();
        if(m_NumIterationsPerformed == 0)
            stringbuffer.append("AdaCost: No model built yet.\n");
        else
        if(m_NumIterationsPerformed == 1)
        {
            stringbuffer.append("AdaCost: No boosting possible, one classifier used!\n");
            stringbuffer.append((new StringBuilder()).append(m_Classifiers[0].toString()).append("\n").toString());
        } else
        {
            stringbuffer.append("AdaCost: Base classifiers and their weights: \n\n");
            for(int i = 0; i < m_NumIterationsPerformed; i++)
            {
                stringbuffer.append((new StringBuilder()).append(m_Classifiers[i].toString()).append("\n\n").toString());
                stringbuffer.append((new StringBuilder()).append("Weight: ").append(Utils.roundDouble(m_Betas[i], 2)).append("\n\n").toString());
            }

            stringbuffer.append((new StringBuilder()).append("Number of performed Iterations: ").append(m_NumIterationsPerformed).append("\n").toString());
        }
        
        
        stringbuffer.append(new StringBuilder()).append("AdaCost using ");
        if(m_MinimizeExpectedCost)
            stringbuffer.append(new StringBuilder()).append("minimized expected misclasification cost\n").toString();
        else
            stringbuffer.append(new StringBuilder()).append("reweighted training instances\n").toString();
        stringbuffer.append(new StringBuilder()).append("\n").append(getClassifierSpec()).append("\n\nClassifier Model\n").append(m_Classifier.toString()).append("\n\nCost Matrix\n").append(m_CostMatrix.toString()).toString();

        return stringbuffer.toString();
    }
    
    

    private static int MAX_NUM_RESAMPLING_ITERATIONS = 10;
    protected double m_Betas[];
    protected int m_NumIterationsPerformed;
    protected int m_WeightThreshold;
    protected boolean m_UseResampling;
    protected int m_NumClasses;
    

    public static final int MATRIX_ON_DEMAND = 1;
    public static final int MATRIX_SUPPLIED = 2;
    public static final Tag TAGS_MATRIX_SOURCE[] = {
        new Tag(1, "Load cost matrix on demand"), new Tag(2, "Use explicit cost matrix")
    };
    protected int m_MatrixSource;
    protected File m_OnDemandDirectory;
    protected String m_CostFile;
    protected CostMatrix m_CostMatrix;
    protected boolean m_MinimizeExpectedCost;
    
    
}