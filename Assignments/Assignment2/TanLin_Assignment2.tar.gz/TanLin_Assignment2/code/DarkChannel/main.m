clear
clc
DatesetPath =  'D:\Pictures\original\';
ResultPath = 'D:\Pictures\original\DHP\';

DatesetDir = dir(strcat(DatesetPath,'*.jpg'));
LenDir = size(DatesetDir,1);


for i=1:LenDir
    I = imread(strcat(DatesetPath,DatesetDir(i).name));
    
	[Result,tmap,tmap_ref ] = darkChannel(I);
    
    imwrite(Result,strcat(ResultPath,DatesetDir(i).name));
end