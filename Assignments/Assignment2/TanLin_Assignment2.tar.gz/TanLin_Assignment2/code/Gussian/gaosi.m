clc; close all;clear;
imgPath = 'E:\cv\cv_deblurring_dataset\dataset\';
outputPath = 'E:\cv\cv_deblurring_dataset\gaosi\';
mkdir(outputPath);
inputPath = dir(imgPath);
 for imgNum = 1:length(inputPath)
        if inputPath(imgNum).name(1)=='.'
            continue;
        end
        inputImgName1 = strcat(inputPath(imgNum).name);
        inputImgName2 = strcat(imgPath,inputImgName1);
        RGB = imread(inputImgName2);
        sigma = 1.6;
gausFilter = fspecial('gaussian',[5 5],sigma);

r=imfilter(RGB(:,:,1),gausFilter,'replicate');
g=imfilter(RGB(:,:,2),gausFilter,'replicate');
b=imfilter(RGB(:,:,3),gausFilter,'replicate');
newrgb=cat(3,r,g,b);
imwrite(uint8(newrgb), [outputPath,'gaosi_',inputImgName1]) ;
     
end