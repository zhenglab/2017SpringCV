clear 
clc

fid = fopen('/media/scw4750/25a01ed5-a903-4298-87f2-a5836dcb6888/WHOI-MVCO/2014delete/2014_4origin.txt');
SetInfo = textscan(fid,'%s%d');
fclose(fid);
SetInfo = SetInfo{1,1};
SetNum = length(SetInfo);
TemplateResult = ('/media/scw4750/25a01ed5-a903-4298-87f2-a5836dcb6888/WHOI-MVCO/2014_4BF');
for i = 1:SetNum
    imageNameNum = strfind(SetInfo{i,1},'/');
    classname = SetInfo{i,1}((imageNameNum(1,6)+1):(imageNameNum(1,7)-1));
    filename = strcat(TemplateResult,'/',classname);
    if ~exist(filename)
        mkdir(filename);
    end
    imgname = SetInfo{i,1}((imageNameNum(1,7)+1):end);
    impath = SetInfo{i,1};
    I = imread(impath);
    I=double(I)/255;
    w = 5; 
    sigma = [3 0.1];
    I1=bfilter2(I,w,sigma);
    I2=bfilter2(I1,w,sigma);
    I3=bfilter2(I2,w,sigma);
	
    resultimg = [TemplateResult '/' classname '/' imgname];
    imwrite(I3,resultimg);
end  
