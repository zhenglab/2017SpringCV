clear
clc
DatesetPath =  'Dataset\';
ResultPath = 'AHEResult\';

DatesetDir = dir(strcat(DatesetPath,'*.png'));
LenDir = size(DatesetDir,1);

for i=1:LenDir
    I = imread(strcat(DatesetPath,DatesetDir(i).name));
    [m,n,~] = size(I);
    I_hsv = rgb2hsv(I);
    V_channel = I_hsv(:,:,3);
    
    V_histeq = adapthisteq(V_channel);
    
    Result = zeros(m,n,3);
    Result(:,:,1) = I_hsv(:,:,1);
    Result(:,:,2) = I_hsv(:,:,2);
    Result(:,:,3) = V_histeq;
    Result = hsv2rgb(Result);
    imwrite(Result,strcat(ResultPath,DatesetDir(i).name));
end