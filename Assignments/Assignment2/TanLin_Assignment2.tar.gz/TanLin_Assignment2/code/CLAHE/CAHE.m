clear
clc
DatesetPath =  'D:\Pictures\original\';
ResultPath = 'D:\Pictures\original\CLAHE\';

DatesetDir = dir(strcat(DatesetPath,'*.jpg'));
LenDir = size(DatesetDir,1);

for i=1:LenDir
    I = imread(strcat(DatesetPath,DatesetDir(i).name));
    [m,n,~] = size(I);
    I_hsv = rgb2hsv(I);
    V_channel = I_hsv(:,:,3);
    
    V_histeq = adapthisteq(V_channel,'clipLimit',0.02,'Distribution','rayleigh');
    
    Result = zeros(m,n,3);
    Result(:,:,1) = I_hsv(:,:,1);
    Result(:,:,2) = I_hsv(:,:,2);
    Result(:,:,3) = V_histeq;
    Result = hsv2rgb(Result);
    imwrite(Result,strcat(ResultPath,DatesetDir(i).name));
end