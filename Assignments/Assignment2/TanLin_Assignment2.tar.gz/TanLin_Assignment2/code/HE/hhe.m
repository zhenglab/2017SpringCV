clc; close all;clear;
imgPath = 'E:\cv\cv_deblurring_dataset\dataset\';
outputPath = 'E:\cv\cv_deblurring_dataset\HE\';
mkdir(outputPath);
inputPath = dir(imgPath);
 for imgNum = 1:length(inputPath)
        if inputPath(imgNum).name(1)=='.'
            continue;
        end
        inputImgName1 = strcat(inputPath(imgNum).name);
        inputImgName2 = strcat(imgPath,inputImgName1);
        RGB = imread(inputImgName2);
R=RGB(:,:,1);
G=RGB(:,:,2);
B=RGB(:,:,3);
r=histeq(R);
g=histeq(G);
b=histeq(B);
newrgb=cat(3,r,g,b);
imwrite(uint8(newrgb), [outputPath,'HE_',inputImgName1]) ;
     
end