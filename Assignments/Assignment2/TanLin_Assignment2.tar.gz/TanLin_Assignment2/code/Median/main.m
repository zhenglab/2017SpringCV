clear
clc
DatesetPath =  'Dataset\';
ResultPath = 'MedianResult\';

DatesetDir = dir(strcat(DatesetPath,'*.png'));
LenDir = size(DatesetDir,1);


for i=1:LenDir
    I = imread(strcat(DatesetPath,DatesetDir(i).name));
    [m,n,c] = size(I);
    Result = zeros(m,n,c);
    
    for j=1:c
        Result(:,:,j) = medfilt2(double(I(:,:,j)));
    end
    Result = uint8(Result./max(Result(:))*255);
    
    imwrite(Result,strcat(ResultPath,DatesetDir(i).name));
end