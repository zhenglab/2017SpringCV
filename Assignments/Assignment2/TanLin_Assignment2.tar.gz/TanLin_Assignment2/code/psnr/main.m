clear
clc
GroundTruthPath = 'E:\MATLAB2014a\work\֣������ҵ\2\GroundTruth\';

EvaCell = cell(1,10);

EvaCell{1}.name = 'AdaptHistEq';
EvaCell{1}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\AdaptHistEqResult\';
EvaCell{1}.psnr = 0;

EvaCell{2}.name = 'BilateralFilter';
EvaCell{2}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\BilateralFilterResult\';
EvaCell{2}.psnr = 0;

EvaCell{3}.name = 'ContrastAdaptHistEq';
EvaCell{3}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\ContrastAdaptHistEqResult\';
EvaCell{3}.psnr = 0;

EvaCell{4}.name = 'DarkChannel';
EvaCell{4}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\DarkChannelResult\';
EvaCell{4}.psnr = 0;

EvaCell{5}.name = 'GaussianFilter';
EvaCell{5}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\GaussianFilterResult\';
EvaCell{5}.psnr = 0;

EvaCell{6}.name = 'HistEq';
EvaCell{6}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\HistEqResult\';
EvaCell{6}.psnr = 0;

EvaCell{7}.name = 'L0';
EvaCell{7}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\L0Result\';
EvaCell{7}.psnr = 0;

EvaCell{8}.name = 'L0Regula';
EvaCell{8}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\L0RegulaResult\';
EvaCell{8}.psnr = 0;

EvaCell{9}.name = 'MeanFilter';
EvaCell{9}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\MeanFilterResult\';
EvaCell{9}.psnr = 0;

EvaCell{10}.name = 'MedianFilter';
EvaCell{10}.path = 'E:\MATLAB2014a\work\֣������ҵ\2\MedianFilterResult\';
EvaCell{10}.psnr = 0;

GTDir = dir(strcat(GroundTruthPath,'*.png'));
DataDir = dir(strcat(EvaCell{1}.path,'*.png'));
LenDir = size(DataDir,1);

for Method = 1:length(EvaCell)
    index=1;
    for i = 1:LenDir
  
		GT = im2double(imread(strcat(GroundTruthPath,GTDir(index).name)));
        if mod(i,8)~=0
            index = index;
        else
            index = index + 1;
        end
        
		DeBlur = im2double(imread(strcat(EvaCell{Method}.path,DataDir(i).name)));
        
        EvaCell{Method}.psnr = EvaCell{Method}.psnr + PSNR(GT,DeBlur);
  
    end
    EvaCell{Method}.psnr = EvaCell{Method}.psnr/LenDir;
end

save('Evaluation.mat','EvaCell');


