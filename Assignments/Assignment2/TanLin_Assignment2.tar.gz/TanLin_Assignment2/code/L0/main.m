clear
clc
DatesetPath =  'Dataset\';
ResultPath = 'L0Result\';

DatesetDir = dir(strcat(DatesetPath,'*.png'));
LenDir = size(DatesetDir,1);

for i=1:LenDir
%     I = imread(strcat(DatesetPath,DatesetDir(i).name));
    
    [Result, retKernel] = Non_Uniform_L0(strcat(DatesetPath,DatesetDir(i).name),9,2e-3,4e3,0.1);
    
    imwrite(Result,strcat(ResultPath,DatesetDir(i).name));
end