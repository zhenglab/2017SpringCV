clear
clc
DatesetPath =  'Dataset\';
ResultPath = 'L0RegulaResult\';
KernelPath = 'Kernel\';

DatesetDir = dir(strcat(DatesetPath,'*.png'));
LenDir = size(DatesetDir,1);

lambda_tv = 0.01;
lambda_l0 = 2e-3;
weight_ring = 1;

for i=1:LenDir
    I = im2double(imread(strcat(DatesetPath,DatesetDir(i).name)));
    
    if mod(i,8)~=0
        index=mod(i,8);
    else
        index=8;
    end
    k = double(imread(strcat(KernelPath,num2str(index),'.png')));
    kernel = k./sum(k(:));
    
    Result = ringing_artifacts_removal(I, kernel, lambda_tv, lambda_l0, weight_ring);
    
    imwrite(Result,strcat(ResultPath,DatesetDir(i).name));
end