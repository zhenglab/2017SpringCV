clear
clc
DatesetPath =  'Dataset\';
ResultPath = 'MeanResult\';

DatesetDir = dir(strcat(DatesetPath,'*.png'));
LenDir = size(DatesetDir,1);

kernel = fspecial('average',[5,5]);

for i=1:LenDir
    I = imread(strcat(DatesetPath,DatesetDir(i).name));
    
    Result = meanfilter(I,kernel);
    
    imwrite(Result,strcat(ResultPath,DatesetDir(i).name));
end