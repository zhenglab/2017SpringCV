function Result = meanfilter(I,kernel)

    addrow = floor(size(kernel,1)/2);
    [m,n,~] = size(I);
    img = zeros(m+2*addrow,n+2*addrow,3);
    
    img(addrow+1:m+addrow,addrow+1:n+addrow,:) = I(:,:,:);
    img(1:addrow,addrow+1:n+addrow,:) = I(1:addrow,:,:);
    img(1:m+addrow,addrow+n+1:end,:) = img(1:m+addrow,n+1:n+addrow,:);
    img(m+addrow+1:end,addrow+1:end,:) = img(m+1:m+addrow,addrow+1:end,:);
    img(1:end,1:addrow,:) = img(1:end,addrow+1:2*addrow,:);

	for j = 1:3
		Result(:,:,j) = filter2(kernel,img(:,:,j));
		Result(:,:,j) = uint8(Result(:,:,j)./max(max(Result(:,:,j))).*255);
    end
    Result = uint8(Result./max(Result(:))*255);
    
    Result = Result(addrow+1:m+addrow,addrow+1:n+addrow,:);

end